# 아래 코드는 변경하지 마세요!
class counter:
    def __init__(self, function):
        self.function = function
        self.cnt = 0

    def __call__(self, *args, **kwargs):
        self.cnt += 1
        return self.function(*args, **kwargs)

# 3 - 1
@counter
def fibonacci(n):
    if n == 0:
        return 0
    if n == (1 or 2):
        return 1
    DP = [1, 1]
    for i in range(1, n - 1):
        DP.append(DP[i] + DP[i - 1])
    return DP[n - 1]

# 3 - 2
import itertools

@counter
def coin_exchange(piece_price, piece_price_len, total_price):
    coin_list = []
    min_coin = min(piece_price)
    for n in range(1, (total_price // min_coin) + 1):
        coin_list += [(list(x), sum(list(x))) for x in itertools.combinations_with_replacement((piece_price), n) if sum(list(x)) == total_price]
    
    return len(coin_list)


if __name__ == "__main__":
    # for i in range(0, 30):
    #     print(f'{i} -> {fibonacci(i)}')
    print('### 3 - 1 ###')
    print(fibonacci(5))

    print('### 3 - 2 ###')
    total_price = int(input('교환할 동전금액을 입력하세요(단위 : 원) : '))
    piece_price = list(map(int, input('얼마짜리 동전으로 교환하시겠습니까?(단위 : 원) ').split()))
    piece_price_len = len(piece_price)

    exchange_way = coin_exchange(piece_price, piece_price_len, total_price) 
    print('교환할 수 있는 방법은',exchange_way,'가지 입니다.') 
