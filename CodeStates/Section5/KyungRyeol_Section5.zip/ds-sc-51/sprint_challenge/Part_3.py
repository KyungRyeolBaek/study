# 조건1-1 : 'GroudVehicle 클래스'에서 'num_wheels 변수'의 기본값이 4가 되도록 기본 생성자 코드를 작성하세요.
# 조건1-2 : 'GroudVehicle 클래스'에서 'vroong'을 반환하는 'drive() 메소드'를 추가하세요.

class GroundVehicle:
    def __init__(self):
        self.num_wheels = 4

    def drive(self):
        return 'vroong'


# 조건2-1 : 'GroundVehicle 클래스'의 서브클래스인 'Motorcycle 클래스'를 선언한다.
# 조건2-2 : 'Motorcycle 클래스'를 인스턴스화할 때, 자동으로 'num_wheels 변수'를 수퍼클래스의 생성자에 전달하여 2로 설정한다.
# 조건2-3 : 'GroundVehicle 클래스'의 'drive() 메소드'를 오버라이드하고 'Bang'을 반환하도록 합니다.

class Motorcycle(GroundVehicle):
    def __init__(self):
        self.num_wheels = 2

    def drive(self):
        return 'Bang'

vehicles = [
    GroundVehicle(),
    GroundVehicle(),
    Motorcycle(),
    GroundVehicle(),
    Motorcycle(),
]

# 조건3-1 : 위에서 선언된 클래스에 대해 각각 'drive() 메소드'의 호출결과를 출력하세요.
def print_method():
    for vehicle in vehicles:print(vehicle.drive())
        


if __name__ == "__main__":
    print_method()
