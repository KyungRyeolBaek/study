def part4(score_list):
    count = {}
    for score in range(11):
        count[score*10] = 0

    for score in score_list:
        if score >= 0:
            count[(score // 10)*10] += 1
        else:
            pass

    for score, num in count.items():
        print("{} 점대 - : {} 명".format(score, num))

if __name__ == "__main__":
    score_list = [1, 11, 21, 31, 41, 51, 61, 71, 81, 91, 100, -1 ]
    part4(score_list)

