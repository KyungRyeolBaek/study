python painter_gmcnn.py --load_model_dir ./checkpoints/places2_512x680_freeform/ --img_shapes 512,680 --mode silent
