python test.py --dataset paris_streetview --data_file ./imgs/paris-streetview_256x256/ --load_model_dir ./checkpoints/paris-streetview_256x256_rect --random_mask 0
#python test.py --dataset paris_streetview --data_file ./imgs/paris-streetview_256x256/ --load_model_dir ./checkpoints/paris-streetview_256x256_rect --random_mask 1
#python test.py --dataset celebahq --data_file /data/yiwang/download/celeba_hd_256/val.txt --load_model_dir /data/yiwang/proj/gmcnn-refactor/checkpoints/celebahq_256x256_rect --seed 1
