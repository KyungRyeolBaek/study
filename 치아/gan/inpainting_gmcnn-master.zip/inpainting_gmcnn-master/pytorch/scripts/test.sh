python test.py --dataset celebahq256 --data_file ./imgs/celebahq_256x256/ --load_model_dir ./checkpoints/celebahq256_rect --random_mask 0
