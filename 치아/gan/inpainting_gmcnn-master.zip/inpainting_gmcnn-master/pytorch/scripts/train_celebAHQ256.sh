python train.py --dataset celebahq --data_file [DATASET_TRAININGFILE] --mask_type rect --gpu_ids 0 --pretrain_network 1 --batch_size 8
#python train.py --dataset celebahq --data_file [DATASET_TRAININGFILE] --gpu_ids 0 --pretrain_network 0 --load_model_dir [PRETRAINED_MODEL_PATH] --batch_size 6
